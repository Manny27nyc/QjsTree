<?php

	/**
	 * The QjsTree plugin.
	 * Use this class to implement your custom logic, or
	 * override the default behaviour.
	 */

	/**
	 * The QjsTree plugin.
	 * 
	 * Use this class to implement your custom logic, or
	 * override the default behaviour.
	 */
	class QjsTree extends QjsTreeBase
	{
	}
?>